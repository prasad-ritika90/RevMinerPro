package edu.CSE454.locationFinder;

import android.location.Location;

public abstract class LocationResult{
    public abstract void gotLocation(Location location);
}