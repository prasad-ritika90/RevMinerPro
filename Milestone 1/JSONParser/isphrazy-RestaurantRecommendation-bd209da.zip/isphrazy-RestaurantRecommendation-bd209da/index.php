<?php
	include 'pattern.php';
	
	print_head();
	
	print_search_bar();
	
	print_bottom();

?>

