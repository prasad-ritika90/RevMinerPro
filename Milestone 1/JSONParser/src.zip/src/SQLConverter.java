import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * 
 * Converts to SQL format 
 *
 */
public class SQLConverter {
	
	Set<Restaurant> restaurants; //contains all restaurants
	PrintStream output;
	LinkedHashSet<String> attributes;
	
	SQLConverter(Set<Restaurant> r, LinkedHashSet<String> a) throws FileNotFoundException {
		restaurants = r;
		output = new PrintStream(new File("sql.data"));
		attributes = a; 
	}
	
	/**
	 * Outputs create table command 
	 */
	public void createTable() {
		
	}
	
	/**
	 * Outputs commands to insert into SQL database
	 */
	public void insert() {
		
	}
	

}
