import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import org.json.JSONException;


/**
 * 
 * parses JSON to SQL
 *
 */



public class parseJSONtoSQL {
	
	static final String INPUT_FILE = "Restaurants.data";
	
	public static void main(String[] args) throws JSONException, FileNotFoundException {
		
		JSONParser2 jp2 = new JSONParser2(INPUT_FILE);
		jp2.createAttributes();
		jp2.getRestaurants();
		jp2.printRestaurants();
		SQLConverter sql = new SQLConverter(jp2.restaurants,jp2.attributes);
		
	}
	

}
